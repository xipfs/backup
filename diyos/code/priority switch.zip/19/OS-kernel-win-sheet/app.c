void api_putchar(int c);

void main() {
    api_putchar('A');
    return;
}
