void api_putchar(int c);

void main() {
//    char b[1024];
  //  b[1280] = 'A';
    
    while(1){}
//     api_putchar('A');
    return;
}



